<html>
<body>

<head>
<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>


</head>
<!--
<form action="welcome_get.php" method="post">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>


<form action="welcome_get.php" method="get">
Name: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
<input type="submit">
</form>

<form action="welcome_get.php" method="post">
账号: <input type="text" name="username"><br>
密码: <input type="password" name="password"><br>
<input type="submit">
</form>
-->








</body>
</html>
