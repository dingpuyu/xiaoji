<html><body><h1>It works!</h1></body></html>
<?php phpinfo();?>
