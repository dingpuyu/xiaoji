<?php

include("MMysql.class.php");

$configArray = array('host' => 'localhost', 'port'=>3306 , 'user'=>'root' , 'passwd'=>'root','dbname'=>'XJDB');

$mysql = new MMysql($configArray);

$account = $_GET['account'];

$accountSql =  "select *  from USERINFOTABLE where ACCOUNT='".$account."';";

$passwordSql = "select * from USERINFOTABLE where ACCOUNT='".$account."';";

$result = $mysql->doSql($sql);


for ($i=0; $i < count($result); $i++) { 
	$column = $result[$i];
	echo json_encode($column);
}

?>
