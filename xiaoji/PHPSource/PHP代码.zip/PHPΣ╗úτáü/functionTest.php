<DOCTYPE html>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<html>
<body>

<h3 align=center>函数练习</h3>

<?php
function familyName($fname,$year){
    echo "$fname Zhang.Born in $year <br>";
}

familyName("hehe",1222);
familyName("haha",19992);
?>

<?php
$cars=array("Volvo","BMW","SAAB");
$arrlength=count($cars);

for($x=0;$x<$arrlength;$x++){
    echo "数字是：" . $cars[$x] . "<br>";
}


?>

<?php
$age=array("Peter"=>"34","Ben"=>"36","Joe"=>"43");

$age['Peter']="100";
$age['Ben']="102";
$age['Joe']="103";

foreach($age as $x=>$x_value){
    echo "Key=" . $x . ",Value=" . $x_value;
    echo "<br>";
}

$cars=array("Volvo","BMW","SAAB");

rsort($cars);

for($i=0;$i<count($cars);$i++){
    echo $cars[$i] . "<br>";
}

foreach($GLOBALS as $x=>$x_value){
    echo "Key=" . $x . ",Value=" . $x_value;
    echo "<br>";
}

?>

<?php
echo $_SERVER['REMOTE_ADDR'];


?>




</html>
</body>

