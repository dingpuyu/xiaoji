<!DOCTYPE html>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<html>
<body>

<?php
echo "<h2>PHP is fun!</h2>";
echo "Hello world!<br>";
echo "I'm about to learn PHP!<br>";
echo "This","String","Was","made","With multiple parameters";
?>

<?php
$txt1="Learn PHP";
$txt2="W3School.com.cn";
$cars=array("Volvo","BMW","SAAB");

print $txt1;
print "<br>";
print "Study PHP at $txt2";
print "My car is a {$cars[0]}";
?>


<?php
$x = 5892;
var_dump($x);
echo "<br>";
$x = -345;
var_dump($x);
echo "<br>";
$x = 0x8c;
var_dump($x);
echo "<br>";
$x = 046;
var_dump($x);
?>

<?php
$cars=array("Volvo","BMW","SAAB");
var_dump($cars);
?>





</body>
</html>
