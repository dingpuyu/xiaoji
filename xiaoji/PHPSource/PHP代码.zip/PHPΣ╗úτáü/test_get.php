<html>
<body>


<?php

$age=array("Result"=>true);

echo "UserName:" . $_GET['username'] . "<br>";
echo "Password:" . $_GET['password'];

echo $age;

?>

</body>
</html>
