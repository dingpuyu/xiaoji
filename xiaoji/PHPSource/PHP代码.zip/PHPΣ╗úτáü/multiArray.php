<!DOCTYPE html>
<html>
<head>
	<title>多维数组学习</title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
</head>
<body>


<?php

class Person{
    public $name = "";
    public $dataArray = [];

}

$cars = array
(
    array("Volvo",22,19),
    array("BMW",15,12),
    array("Saab",4,3),
    array("Land Rover",12,35)
);



$xiaoming = new Person;

$xiaoming->dataArray = $cars;

echo json_encode($xiaoming);

?>


<?php 
for ($row=0;$row < 4;$row++){
	echo "<p><b>Row number $row</b></p>";
	echo "<ul>";
	for ($col=0; $col < 3; $col++) { 
		echo "<li>".$cars[$row][$col]."</li>";
	}
	echo "</ul>";
}

?>

<?php
date_default_timezone_set("Asia/Shanghai");
echo "今天是 " . date("Y/m/d") . "<br>";
echo "今天是 " . date("Y/m/d") . "<br>";
echo "今天是 " . date("Y-m-d") . "<br>";
echo "今天是 " . date("1");

echo "现在时间是 " . date("h:i:sa");
?>



<?php
$d = mktime(2,12,3,4,12,2016);

echo "创建日期是 " . date("Y-m-d h:i:sa",$d);


?>





<?php
include 'register.php';

?>






</body>
</html>