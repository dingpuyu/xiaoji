<!DOCTYPE html>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<html>
<body>

<h1>我的第二张PHP页面</h1>

<?php echo "PHP是世界上最好的语言!"; ?>

/*
<?php
ECHO "Hello world!<br>";
echo "Hello WOrld!<br>";
EcHo "Hello World!<br>";
?>

<?php 

$color="Red";
echo "My car is " . $color . "<br>";
echo "My car is " . $COLOR . "<br>";
echo "My car is " . $coLOR . "<br>";
?>

<?php
$x=5;
$y=6;
$z=$x+$y;
echo $z;
?>

<?php
$txt="Hello World!";
$x=5;
$y=10.5;
?>
*/

<?php
$x=5;
function myTest(){
    global $x,$y;
    echo "<p>测试函数内部的变量:</p>";
    echo "变量x是：$x";
    echo "<br>";
    echo "变量 y 是：$x";

    $GLOBALS['x']=100;
}

myTest();

echo "<p>测试函数之外的变量：</p>";
echo "变量x 是$x";
echo "<br>";
echo "变量y是:$y";
?>


</body>
</html>
