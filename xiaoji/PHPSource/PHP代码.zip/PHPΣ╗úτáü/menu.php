<!DOCTYPE html>
<html>
<head>
	<title></title>
	<meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
</head>
<body>


<?php

$myfile = fopen("webdictionary.txt","r") or die("Unable to open file");


while(!feof($myfile)){
echo fgets($myfile);	
}





fclose($myfile);

?>


</body>
</html>