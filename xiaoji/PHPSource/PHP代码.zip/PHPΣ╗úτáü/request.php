u<DOCTYPE html>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<html>
<body>

<form method="post" action"<?php echo $_SERVER['PHP_SELF'];?>">
Name: <input type="text" name="fname">
<input type="submit">
</form>

<?php
$name = $_REQUEST['fname'];
echo $name;
?>


<a href="test_get.php?subject=PHP&web=w3school.com.cn">测试 $GET</a>

<form action="welcome.php" method="post">
Name: <input type="text" name="name"><br>
E-Mail: <input type="text" name="email"><br>
<input type="submit">
</form>


</body>
</html>
