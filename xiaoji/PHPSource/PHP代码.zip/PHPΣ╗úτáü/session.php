<?php
session_start();
$_SESSION['views']=1;
?>

<html>
<body>

<?php

echo "pageViw: " . $_SESSION['views'];

?>

</body>
</html>
