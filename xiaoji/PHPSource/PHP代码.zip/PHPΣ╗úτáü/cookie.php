<?php
echo "<br>";
setcookie("user","Alex Porter",time()-3600);
?>

<html>
<body>

<?php

echo $_COOKIE["user"];

echo "<br>";

print_r($_COOKIE);

?>


<?php
if(isset($_COOKIE["user"]))
    echo "Welcome " . $_COOKIE["user"] . "!<br />";
else
    echo "Welcome guest!<br />";


?>


<?php

echo "删除cookie";

setcookie("user",time()-3500);

if(isset($_COOKIE["user"]))
    echo "Welcome " . $_COOKIE["user"] . "!<br />";
else
    echo "Welcome guest!<br />";

?>


</body>
</html>
