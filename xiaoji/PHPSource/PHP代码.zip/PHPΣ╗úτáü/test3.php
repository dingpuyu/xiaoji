<DOCTYPE html>
<meta http-equiv=Content-Type content="text/html;charset=utf-8">
<html>
<body>

<h1>标题呵呵呵呵</h1>

<?php
class Car
{
    var $color;
    function Car($color="green"){
	$this->color = $color;
    }

    function what_color(){
	return $this->color;
    }
}

?>

<?php
//对大小写敏感的字符串
    define("GREETING","Welcome to W3School.com.cn!");
    echo GREETING;
//对大小写不敏感的常量
    define("GREATING","Welcome to xiaotei's zone",true);
    echo greating;


    echo strlen("Hello World!");

    print "<br>";

    echo strpos("Hello World!","World");
?>



</html>
</body>

